# Code of Conduct

## Expectation of Behavior

* Treat everyone with dignity and respect.
* No harassment.
* Gracefully accept criticism.
* No sex.
* No politics.
* No trolling.

Report unacceptable behavior to tonygermaneri@gmail.com.
